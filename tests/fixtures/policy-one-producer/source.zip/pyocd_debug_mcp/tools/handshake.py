"""Initialization handshake and advisory operating guidance."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from pyocd_debug_mcp.kernel.registry import ToolRegistry
from pyocd_debug_mcp.kernel.run_state import ServerRun

HANDSHAKE_TOOL_NAME = "initialization_handshake"
HANDSHAKE_DESCRIPTION = (
    "Call this first after connecting to learn the server's current safe operating workflow."
)


def build_initialization_guidance(
    registry: ToolRegistry,
    tool_descriptions: Mapping[str, str] | None = None,
    server_run: ServerRun | None = None,
) -> str:
    """Build side-effect-free guidance from the current advertised tool list."""

    visible_tools = registry.advertised()
    descriptions = tool_descriptions or {}
    tool_index = "\n".join(
        f"- {name}: {' '.join(descriptions.get(name, 'Visible MCP tool.').split())}"
        for name in visible_tools
    )
    run_evidence = ""
    if server_run is not None:
        run_evidence = f"""
Server Run identity:
- run_id: {server_run.run_id}
- started_at: {server_run.started_at_text}
These values identify this in-memory server process; they grant no authority and change after restart.
"""
    return f"""Guarded Hardware Server operating guidance
{run_evidence}

The server intentionally hides some hardware-control tools at startup. The currently visible
tool list is authoritative: never guess, request, or call an unlisted tool.

Currently visible tools:
{tool_index}

C/C++ semantic analysis works without a board, setup, validation or hardware permissions.
Start with get_code_analysis_status to inspect clangd and the selected compile_commands.json.
Use find_code_definition, find_code_references, get_code_hover and get_code_diagnostics for
saved files only, with 1-based Unicode code-point positions. Unsaved editor buffers are outside
this contract. Analysis covers one selected build; index completeness is unverified, empty
references do not prove dead code, and diagnostics are not firmware verification. The launch
project root is fixed; workspace_path only labels activity and cannot redirect analysis.

Guarded actions are exposed through a corresponding *-plan tool. A *-plan is an interactive
two-step preparation gate, not the hardware action: first call with every parameter set to NULL, read the
complete returned guide, then call the same *-plan with only its exact JSON plan object. If
accepted, the response names and exposes the real action. Never put prose, Markdown, flattened
action fields, or extra keys in a plan call. A visible tool is not proof of authorization; the
server also enforces physical handler locks and all board-specific safety checks.

Before downloading any large SDK, RTOS, toolchain, device pack, or library, perform a bounded
local-first discovery. Check explicit paths and environment variables, the current project and
its parents, and normal vendor install locations in the user's home and application directories.
This includes any existing vendor SDK, RTOS, compiler, debugger, and toolchain trees. Validate the discovered product, version, target support, and executable tools
before reuse; never trust a folder name alone and never recursively crawl the whole disk. Use a
network download only when no compatible local copy exists, and tell the user what was missing
before fetching a large dependency. Do not copy or persist unrelated files found during discovery.

Build firmware with the provider-neutral general helper argv template returned by
get_setup_status.build_guidance. First inspect the project's build files and resolve its exact
executable, argv, cwd, environment, and outputs. Prefer a compatible local installation, but when
none exists normal dependency/toolchain acquisition is allowed. Put the exact argv after `--`; the
helper executes it directly without a shell and inherits network access unless you intentionally
pass `--offline`. That flag applies best-effort environment guards for common dependency clients;
it is not an OS network sandbox, so inspect the actual process/log evidence. The server does not
detect or select a provider, SDK, compiler, target, fixed path, or output convention. After any native
build whose outputs are scattered or vendor-named, use the
always-visible collect_build_artifacts MCP tool with the
explicit paths the build actually produced. For guarded application or bootloader work, normally
collect a coherent ELF and linker map and set expected_roles to ["elf", "map"]. Do not ask the
collector to search or build. It only creates canonical, hashed provenance. Continue with the
matching flash plan and selected canonical ELF or HEX; use board_safety_refresh only for an actual
stable-map problem. Never treat collection as validation, flash permission, memory authority, or
an open hardware gate.

Dynamic clients should call the newly exposed action directly. Some MCP clients keep static callable
bindings even after notifications/tools/list_changed. If the accepted plan's action is absent
from those bindings, submit only the exact server-returned single-child action_batch fallback
unchanged. This is the sole narrow exception to the no-unlisted-call rule: never invent a hidden
child name, edit fallback arguments, or combine a primary action with a paired repair. The child
still passes through identical plan, permission, validation, gate, freshness, lock, timeout, budget,
event, and cleanup checks.

At startup, ask the user in ordinary conversation for one unique, familiar name for each board
they want to use in this project now, or "no board". Other visible debug probes may remain
unassigned. "no board" is a literal sentinel: pass it by itself, and treat it as never a candidate
board name. If it is mixed with names, clarify the answer before routing.
Never ask the user for structured data, board IDs, connection IDs, or permission values. Never
expose structured payloads, continuation tokens, or internal field names to the user.

After the user answers, call setup_overview with the familiar names. It lists known profiles,
friendly current connections, server-generated board IDs, and exact per-board next-call templates.
Copy those machine values into MCP calls; never ask the user to repeat or invent them. Route a
complete existing profile to validation with load_setup_tool(board_validate) and board_validate.
Follow the server-returned repair route for an incomplete same-identity profile, and the returned
safety-refresh route for a stable-map problem. Route an unknown name to setup through the all-NULL
board_setup-plan first; ask for the exact package-level MCU part number and the authoritative local
datasheet PDF, never a board type or digest, then load board_setup-plan and submit its populated plan
before any other hardware plan. If a physical match is
ambiguous, relay only server-provided friendly choices. Never silently choose, rename, reassign,
or rewrite a profile.

Ordinary conversation is never permission. When a tool requests approval, ask clearly in plain
language and pass approval only through the exact structured parameter named by that tool.

Keep every board isolated. Never reuse another board's validation, approval, plan, parameters,
or result. After a disconnect or the end of this Server Run, repeat validation before guarded
actions.

Validation has exactly three trigger categories: no live proof after initial setup or server
restart; connection identity change after disconnect, reconnect, probe change, or target override;
and possible hardware identity change after identity repair, mismatch, or destructive recovery.
There is no idle validation timeout, and working on another board does not invalidate this one.
Do not validate merely because of an ordinary build or relink, flash, reset or halt, UART work,
safety refresh or full map reconstruction, artifact collection, report, cache, or bookkeeping
change.

If no board is connected, do not begin setup, validation, or hardware actions."""


def _validated_workspace(value: str | None) -> Path | None:
    """Accept a workspace path only if it is absolute, present, and a directory."""

    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    try:
        candidate = Path(text)
        if not candidate.is_absolute() or not candidate.is_dir():
            return None
        return candidate
    except OSError:
        return None


def register_initialization_handshake(
    mcp: FastMCP,
    registry: ToolRegistry,
    server_run: ServerRun | None = None,
    on_workspace: Callable[[Path | None], None] | None = None,
) -> Callable[..., str]:
    """Register and return the handshake handler."""

    def initialization_handshake(workspace_path: str | None = None) -> str:
        """Return current operating guidance; call this first in each Server Run.

        Optionally pass workspace_path: the absolute path of the project directory
        you are working in. It is used only to label this project's activity
        records, never as a place to write and never to relocate any safety
        evidence. An unusable path is ignored rather than refused, because this
        call must always return the operating guidance.
        """

        resolved = _validated_workspace(workspace_path)
        if on_workspace is not None:
            try:
                on_workspace(resolved)
            except Exception:  # noqa: BLE001 - binding never blocks the handshake
                pass
        descriptions = {
            tool.name: tool.description or "Visible MCP tool."
            for tool in mcp._tool_manager.list_tools()  # type: ignore[reportPrivateUsage]
        }
        guidance = build_initialization_guidance(registry, descriptions, server_run)
        if workspace_path is not None and resolved is None:
            guidance = (
                f"{guidance}\n\nNote: the supplied workspace_path was not an existing "
                "absolute directory, so this session's activity records are labelled "
                "unbound. Re-call with a valid absolute path to label them."
            )
        return guidance

    mcp.add_tool(
        initialization_handshake,
        name=HANDSHAKE_TOOL_NAME,
        description=HANDSHAKE_DESCRIPTION,
        structured_output=False,
    )
    return initialization_handshake
