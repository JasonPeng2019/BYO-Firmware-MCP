"""Always-visible, non-authorizing firmware artifact collection tool."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Literal

from pyocd_debug_mcp.artifact_collector import ArtifactRole, collect_artifacts
from pyocd_debug_mcp.project_paths import resolve_project_path

ArtifactRoleName = Literal["elf", "hex", "bin", "map"]


def build_artifact_handlers() -> dict[str, Callable[..., str]]:
    """Build the build-system-neutral artifact collection surface."""

    def collect_build_artifacts(
        output_dir: str,
        elf_path: str | None = None,
        hex_path: str | None = None,
        bin_path: str | None = None,
        map_path: str | None = None,
        expected_roles: list[ArtifactRoleName] | None = None,
    ) -> str:
        """Normalize explicit native-build outputs for later safety inspection.

        Call this after a native IDE or CLI build when its ELF, HEX, BIN, or linker-map files
        are scattered or use vendor-specific names. Supply only paths that the build actually
        produced; this tool never searches a build tree, runs a build, downloads dependencies,
        or accesses hardware. Choose a new or empty output_dir. For an application or bootloader
        that will enter the guarded safety/flash flow, normally include both elf_path and map_path
        and set expected_roles to ["elf", "map"]. HEX-only or BIN-only collection is provenance
        only and does not make an image safe to flash. Continue with the matching flash plan and
        selected canonical ELF or HEX. Use board_safety_refresh only for an actual stable-map
        problem; collection grants no memory authority or gate.
        """

        supplied = {
            ArtifactRole.ELF: elf_path,
            ArtifactRole.HEX: hex_path,
            ArtifactRole.BIN: bin_path,
            ArtifactRole.MAP: map_path,
        }
        try:
            sources = {
                role: resolve_project_path(path)
                for role, path in supplied.items()
                if path is not None
            }
            expected = tuple(ArtifactRole(value) for value in (expected_roles or ()))
            result = collect_artifacts(
                sources,
                resolve_project_path(output_dir),
                producer="mcp-native-build",
                expected_roles=expected,
            )
        except (OSError, RuntimeError, ValueError) as exc:
            return json.dumps(
                {
                    "status": "artifact_collection_refused",
                    "message": str(exc),
                    "remedy": (
                        "Use explicit nonempty build outputs, choose a new or empty output_dir, "
                        "and include every role named in expected_roles. Do not guess paths."
                    ),
                },
                ensure_ascii=False,
                sort_keys=True,
            )

        payload = result.to_payload()
        canonical_paths = {
            record.role.value: str(result.output_dir / record.path) for record in result.artifacts
        }
        has_flash_artifact = "elf" in canonical_paths
        payload.update(
            {
                "canonical_paths": canonical_paths,
                "authority": "provenance_only",
                "safety_handoff": {
                    "status": (
                        "flash_plan_artifact_available" if has_flash_artifact else "provenance_only"
                    ),
                    "next_step": (
                        "Submit the matching application or bootloader flash plan with the "
                        "selected canonical ELF or HEX. Refresh only if the stable map is invalid."
                        if has_flash_artifact
                        else "Obtain and collect a coherent ELF (and matching ELF for any HEX) "
                        "before submitting a flash plan."
                    ),
                    "manifest_consumed_automatically": False,
                    "raw_bin_has_trusted_load_address": False,
                    "opens_hardware_gate": False,
                },
                "agent_guidance": (
                    "Collection finished. Keep the returned paths machine-readable; do not describe "
                    "this as validation or flash authorization."
                ),
            }
        )
        return json.dumps(payload, ensure_ascii=False, sort_keys=True)

    return {"collect_build_artifacts": collect_build_artifacts}
